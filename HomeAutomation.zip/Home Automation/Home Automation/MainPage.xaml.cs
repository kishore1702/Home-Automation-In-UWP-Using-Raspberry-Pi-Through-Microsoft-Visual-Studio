﻿using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.Devices.Gpio;
using System.Threading.Tasks;
// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Home_Automation
{

    public sealed partial class MainPage : Page
    {
        GpioPin light, fan, door,door1, alaram;

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            fan.Write(GpioPinValue.High);
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
           
            fan.Write(GpioPinValue.Low);
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            
            door.Write(GpioPinValue.Low);
            door1.Write(GpioPinValue.High);
            Task.Delay(3500).Wait();
            door1.Write(GpioPinValue.Low);
            
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            alaram.Write(GpioPinValue.High);
            door.Write(GpioPinValue.High);
            door1.Write(GpioPinValue.Low);
            Task.Delay(3500).Wait();
            light.Write(GpioPinValue.Low);
            fan.Write(GpioPinValue.Low);
            door.Write(GpioPinValue.Low);
            
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
           
            alaram.Write(GpioPinValue.Low);
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            
            door.Write(GpioPinValue.High);
            door1.Write(GpioPinValue.Low);
            Task.Delay(3500).Wait();
            door.Write(GpioPinValue.Low);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
           
            light.Write(GpioPinValue.Low);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            light.Write(GpioPinValue.High);
        }

        public MainPage()
        {
            this.InitializeComponent();
            Loaded += MainPage_Load;
            
        }

        private void MainPage_Load(object sender, RoutedEventArgs e)
        {
            var controller = GpioController.GetDefault();
            door = controller.OpenPin(19);
            door1 = controller.OpenPin(26);
            alaram = controller.OpenPin(5);
            fan = controller.OpenPin(13);
            light = controller.OpenPin(6);
            door.SetDriveMode(GpioPinDriveMode.Output);
            door1.SetDriveMode(GpioPinDriveMode.Output);
            alaram.SetDriveMode(GpioPinDriveMode.Output);
            fan.SetDriveMode(GpioPinDriveMode.Output);
            light.SetDriveMode(GpioPinDriveMode.Output);
        }
    }
}
